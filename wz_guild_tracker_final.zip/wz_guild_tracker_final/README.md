
# WZ Guild Tracker — Final Upload ZIP

This ZIP is ready for GitHub upload.  
Just upload **ALL files and folders** to your GitHub repo.

Then deploy on Netlify:
Build command: npm run build  
Publish directory: dist
